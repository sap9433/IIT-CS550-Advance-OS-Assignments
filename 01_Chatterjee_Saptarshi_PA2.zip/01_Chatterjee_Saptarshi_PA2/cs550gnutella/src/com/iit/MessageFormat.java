package com.iit;

import java.io.Serializable;

public class MessageFormat implements Serializable {
    String message_ID;
    int ttl;
    String file_name;
    int fromPeerId;

}
