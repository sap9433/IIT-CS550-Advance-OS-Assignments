package com.iit;

import java.net.*;
import java.util.Properties;
import java.io.*;
import java.util.*;

class LeafNode extends Thread {

    int leafNodePort, connectedSuperpeer, frompeerId, timeToLive;
    String filetodownload, msgid;
    Socket socket = null;
    int[] peersArray;
    MessageFormat MF = new MessageFormat();

    public LeafNode(int leafNodePort, int connectedSuperpeer, String filetodownload, String msgid, int frompeerId, int timeToLive) {
        // Initializing LeafNode local variables.
        this.leafNodePort = leafNodePort;
        this.connectedSuperpeer = connectedSuperpeer;
        this.filetodownload = filetodownload;
        this.msgid = msgid;
        this.frompeerId = frompeerId;
        this.timeToLive = timeToLive;
    }

    public void run() {
        try {
            //Initiate the socket connection to communicate with Superpeer that
            //File exixts or Not.
            socket = new Socket("localhost", leafNodePort);
            OutputStream os = socket.getOutputStream();
            //Object output stream wraps around socket and transfers file
            ObjectOutputStream oos = new ObjectOutputStream(os);
            InputStream is = socket.getInputStream();
            ObjectInputStream ois = new ObjectInputStream(is);
            //Initializing the message with to - from and id trail
            MF.file_name = filetodownload;
            MF.message_ID = msgid;
            MF.fromPeerId = frompeerId;
            MF.ttl = timeToLive;
            //Writing the message
            oos.writeObject(MF);

            peersArray = (int[]) ois.readObject();
        } catch (IOException io) {
            io.printStackTrace();
        } catch (ClassNotFoundException cp) {
            cp.printStackTrace();
        }
    }

    public int[] getarray() {
        return peersArray;
    }
}

// Responsible for initiating File transfer . This class by itself does little
// Mainly delegates work to helper class FileSender.

class FileDownloader extends Thread {

    int portno;
    String FileDirectory;
    ServerSocket serverSocket;

    FileDownloader(int portno, String FileDirectory) {
        this.portno = portno;
        this.FileDirectory = FileDirectory;
    }

    public void run() {
        try {
            // Just create the ServerSocket abstraction and pass that to actual FileSender
            serverSocket = new ServerSocket(portno);
        } catch (IOException io) {
            io.printStackTrace();
        }
        new FileSender(serverSocket, portno, FileDirectory).start();
    }
}

// This class performs the heavy lifting for Actual File send.
class FileSender extends Thread {

    int portno;
    String sharedDirectory, filename;
    ServerSocket socket;

    // Parameterized constructor
    FileSender(ServerSocket socket, int portno, String FileDir) {
        this.socket = socket;
        this.portno = portno;
        this.sharedDirectory = FileDir;
    }

    public void run() {
        try {
            // This is an infinite for loop keeps running at the background , that always listens for
            // incoming query messages . And responds.
            while (true) {
                System.out.println("\n\n (N.B. In the background parallely Waiting for new File download Request) \n\n");
                // Following 4 lines are boilerplate socket and Objectstream code.
                // http://www.java2s.com/Code/Java/Network-Protocol/TransferafileviaSocket.htm
                Socket sock = socket.accept();
                InputStream is = sock.getInputStream();
                ObjectInputStream ois = new ObjectInputStream(is);
                filename = (String) ois.readObject();
                File myFile = new File(sharedDirectory + "/" + filename);
                byte[] mybytearray = new byte[(int) myFile.length()];
                // Using BufferedInputStream to buffer large file content.
                BufferedInputStream bis = new BufferedInputStream(new FileInputStream(myFile));
                bis.read(mybytearray, 0, mybytearray.length);
                OutputStream os = sock.getOutputStream();
                os.write(mybytearray, 0, mybytearray.length);
                //Done writing . Now close the socket and flush stream.
                os.flush();
                sock.close();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

public class Main {
    static String fileName;

    // Entry point of the application.
    public static void main(String[] args) {
        try {
            // Initializing local variables.
            int ports, portserver, ttl;
            int count = 0;
            String msgid, sharedDir;
            ArrayList<Thread> thread = new ArrayList<Thread>();
            // Maintains an associative array of the Leaf nodes.
            ArrayList<LeafNode> peers = new ArrayList<LeafNode>();
            // Parse input arguments to get the topology and shared path
            int peer_id = Integer.parseInt(args[1]);
            sharedDir = args[2];
            Properties prop = new Properties();
            fileName = args[0];
            // Peer startup message.
            System.out.println("Super-peer " + peer_id + " stated with private storage " + sharedDir + " Topology: " + fileName);
            InputStream is = new FileInputStream(fileName);
            //Reading from topology file using Java Properties.
            prop.load(is);
            ports = Integer.parseInt(prop.getProperty("peer" + peer_id + ".serverport"));
            // Initiate the file downloader
            FileDownloader sd = new FileDownloader(ports, sharedDir);
            sd.start();
            portserver = Integer.parseInt(prop.getProperty("peer" + peer_id + ".port"));
            Superpeer cs = new Superpeer(portserver, sharedDir, peer_id);
            cs.start();
            System.out.println("Enter the filename to download a file");
            String filetodownload = new Scanner(System.in).nextLine();
            ++count;
            msgid = peer_id + "." + count;
            String[] neighbours = prop.getProperty("peer" + peer_id + ".next").split(",");
            ttl = neighbours.length;
            //File name to search is been recieved from user . Now search through every neighbours and check
            // Who got the file in it's Leaf.
            for (int i = 0; i < neighbours.length; i++) {
                int connectingport = Integer.parseInt(prop.getProperty("peer" + neighbours[i] + ".port"));
                int neighbouringpeer = Integer.parseInt(neighbours[i]);
                LeafNode cp = new LeafNode(connectingport, neighbouringpeer, filetodownload, msgid, peer_id, ttl);
                Thread t = new Thread(cp);
                t.start();
                // Every leafnode is started as a separate Thread , so that they dont block each other
                thread.add(t);
                peers.add(cp);
            }
            for (int i = 0; i < thread.size(); i++) {
                try {
                    ((Thread) thread.get(i)).join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            int[] peerswithfiles;

            System.out.println("Leafnodes containing the file are: ");
            int peerfromdownload = 0;
            for (int i = 0; i < peers.size(); i++) {
                peerswithfiles = ((LeafNode) peers.get(i)).getarray();
                for (int j = 0; j < peerswithfiles.length; j++) {
                    if (peerswithfiles[j] == 0)
                        break;
                    System.out.println(peerswithfiles[j]);
                    // Randomly selects a leaf node from available leaf nodes
                    // This ios kind of static load balancer.
                    peerfromdownload = peerswithfiles[j];
                }
            }
            System.out.println("\n Selecting leafnode: " + peerfromdownload + " To download file \n");
            int porttodownload = Integer.parseInt(prop.getProperty("peer" + peerfromdownload + ".serverport"));
            // File found . Initiate Download .
            StreamProcessor(peerfromdownload, porttodownload, filetodownload, sharedDir);
            System.out.println("File: " + filetodownload + " downloaded from Leafnode: " + peerfromdownload + " to Leafnode:" + peer_id);
        } catch (IOException io) {
            io.printStackTrace();
        }
    }
    // Responsible for initiating the file Transfer and saving the transferred file to its private storage.
    public static void StreamProcessor(int cspeerid, int csportno, String filename, String sharedDir) {
        try {
              Socket clientsocket = new Socket("localhost", csportno);
            ObjectOutputStream ooos = new ObjectOutputStream(clientsocket.getOutputStream());
            ooos.flush();

            ooos.writeObject(filename);

            String outputFile = sharedDir + "/" + filename;
            byte[] mybytearray = new byte[1024];
            // Boilerplate file transfer code using socket and Object output Stream
            // http://www.java2s.com/Code/Java/Network-Protocol/TransferafileviaSocket.htm
            InputStream is = clientsocket.getInputStream();
            FileOutputStream fos = new FileOutputStream(outputFile);
            BufferedOutputStream bos = new BufferedOutputStream(fos);
            int bytesRead = is.read(mybytearray, 0, mybytearray.length);
            bos.write(mybytearray, 0, bytesRead);
            bos.close();
            clientsocket.close();
            System.out.println(filename + " file is transferred to your private storage: " + sharedDir);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
